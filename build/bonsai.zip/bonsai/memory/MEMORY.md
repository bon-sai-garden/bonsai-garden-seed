---
title: "bonsai — memory index (empty in the shintai; the memory lives in pot)"
type: memory-index
tended-by: bonsai
---
